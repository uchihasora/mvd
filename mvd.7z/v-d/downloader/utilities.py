import os

def validate_url(url):
    return url.startswith("http://") or url.startswith("https://")

def ensure_directory_exists(path):
    if not os.path.exists(path):
        os.makedirs(path)
