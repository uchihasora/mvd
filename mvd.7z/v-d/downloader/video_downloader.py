import os
import yt_dlp

class VideoDownloader:
    def __init__(self, download_path="downloads"):
        self.download_path = download_path
        if not os.path.exists(self.download_path):
            os.makedirs(self.download_path)

    def download_video(self, url, resolution="best"):
        try:
            ydl_opts = {
                'format': f'bestvideo[height<={resolution}]+bestaudio/best',
                'outtmpl': os.path.join(self.download_path, '%(title)s.%(ext)s'),
                'merge_output_format': 'mp4',
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                print(f"Downloading video from {url} at resolution {resolution}")
                ydl.download([url])
                print("Download completed successfully.")
        except Exception as e:
            print(f"Error: {e}")
