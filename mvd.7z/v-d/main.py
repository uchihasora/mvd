from downloader.video_downloader import VideoDownloader

def main():
    print("Welcome to My Video Downloader")
    url = input("Enter the video URL: ")
    resolution = input("Enter the resolution (e.g., 720, 1080): ") or "best"
    downloader = VideoDownloader()
    downloader.download_video(url, resolution)

if __name__ == "__main__":
    main()
